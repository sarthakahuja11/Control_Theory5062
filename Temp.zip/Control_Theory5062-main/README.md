# Control_Theory5062

Contains the coursework and some lab MATLAB/simulink scripts for Control_5062
To be updated with final coursework 
